#include "XPM2.hpp"

namespace prog {
    Image* loadFromXPM2(const std::string& file) {
        return nullptr;
    }

    void saveToXPM2(const std::string& file, const Image* image) {

    }
}
